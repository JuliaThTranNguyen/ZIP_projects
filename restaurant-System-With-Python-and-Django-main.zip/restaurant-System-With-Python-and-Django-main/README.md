# Build A Restaurant Website With Python and Django

Build A Real Restaurant System With Python & Django [Restaurant - Reserve Tables - Blog - About - Contact ]

- i built in this restaurant system :
  - organize meals
  - ordered a meal
  - reserver a table
  - blog

- Our Project Features :
  - post and ad to the site
  - search over ads
  - filter ads
  - reset & change password
  - leave comment on items
  - and much,much more!
